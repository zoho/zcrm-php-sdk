<?php

class RelatedListAPIHandlerTest
{
	
}
?>